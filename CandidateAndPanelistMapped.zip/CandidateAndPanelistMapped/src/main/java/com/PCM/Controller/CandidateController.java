package com.PCM.Controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.PCM.entities.Candidates;
import com.PCM.services.CandidateService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")



public class CandidateController {
	
	@Autowired
	private CandidateService candidateService;

	@GetMapping("/candidates")
	public List<Candidates> getCandidate(){
		return candidateService.getCandidates();
	}
	@GetMapping("/candidates/{id}")
	public Optional<Candidates> getOneCandidate(@PathVariable long id) {
		Optional<Candidates> candidate= candidateService.getCandidate(id);
	    return candidate;
	}
	@PostMapping("/candidates")
	public Candidates postOne(@RequestBody Candidates candidate) {
		return candidateService.addCandidate(candidate);
	}
	@PutMapping("/candidates")
		public Candidates updateOne(@RequestBody Candidates candidate) {
			return candidateService.updateCandidate(candidate);
		}
	@DeleteMapping("/candidates/{id}")
	public void deleteById(@PathVariable long id) {
		candidateService.deleteCandidate(id);
	}

		

	}


