import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Candidate } from '../candidate';
import { CandidateService } from '../candidate.service';
import { Project } from '../project';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-select-candidate-project',
  templateUrl: './select-candidate-project.component.html',
  styleUrls: ['./select-candidate-project.component.css']
})
export class SelectCandidateProjectComponent implements OnInit {

  id:number;
  project:Project = new Project;
  candidates : Candidate[];
  selectCandidate:Candidate = new Candidate;
  constructor(private route:ActivatedRoute , private projectService : ProjectService , private candidateService : CandidateService ,  private router : Router) { }

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];

    this.projectService.getProjectById(this.id).subscribe(data => {
       this.project = data;
    });

    //
    this.getCandidates();
  }

  private getCandidates(){
    this.candidateService.getCandidatesList().subscribe(data => {
        this.candidates = data;
        console.log(this.candidates);
        console.log(data);
 
    });
  }

  selectedInProject(candidate_id:number){
    this.candidateService.getCandidateById(candidate_id).subscribe(data => {
      this.selectCandidate = data;
      console.log("in select" ,this.selectCandidate);
      this.selectCandidate.project=this.project.projectName;
      console.log("after update" ,this.selectCandidate);
      this.candidateService.updateCandidate(candidate_id, this.selectCandidate).subscribe(data => {
         console.log("candidate updated with project name");
      }, error => console.log(error));
      this.project.selected=this.project.selected+1;
      this.projectService.updateProject(this.id , this.project).subscribe(data => {
        console.log("done");
      }, error => console.log(error));

       this.router.navigate(['/view-project',this.id]); 
      // this.router.navigate(['/select-project-candidate',this.id]); 
   });
  }

}
