import { Component, OnInit,PipeTransform } from '@angular/core';

import { PanserveService } from './panserve.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl } from '@angular/forms';
import { Candidate } from './candidate';
import { Panel } from './panel';

@Component({
  selector: 'app-candidate-list',
  templateUrl: './candidate-list.component.html',
  styleUrls: ['./candidate-list.component.css']
})
export class CandidateListComponent implements OnInit {
  // searchTerm!: string;
  // candidates:Candidate[]=[];
  panelist!:Panel;
  filter = new FormControl('');
  email!:String;

  constructor(private pans:PanserveService, private router: Router,private route:ActivatedRoute) { }
  

  ngOnInit(): void {
    this.email=this.route.snapshot.params['email'];
    this.pans.getPanelistId(this.email).subscribe(data => {
      console.log(data);
      this.panelist = data;
    });
    
  }
  candidateDetails(id: number){
    this.router.navigate(['candidate-details', id]);
  }
  
 

}

