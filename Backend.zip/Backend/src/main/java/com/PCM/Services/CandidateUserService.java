package com.PCM.Services;

import com.PCM.Model.*;

import com.PCM.Repositories.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CandidateUserService {

    @Autowired
    private PanCanRepository candidateUserRepository;

    public void addCandidateUsers(List<PanCan> candidateUsers) {
        candidateUserRepository.saveAllAndFlush(candidateUsers);
    }
}
