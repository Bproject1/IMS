package com.PCM.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.PCM.entities.Panelists;
import com.PCM.services.PanelistService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class PanelistController {
	@Autowired
	private PanelistService panelistService;

	@GetMapping("/panelists")
	public List<Panelists> getPanelist(){
		return panelistService.getPanelist();
	}
	@GetMapping("/panelists/{email}")
	public Optional<Panelists> getOnePanelist(@PathVariable String email) {
		Optional<Panelists> panelist= panelistService.getPanel(email);
	    return panelist;
	}
	@PostMapping("/panelists")
	public Panelists postOne(@RequestBody Panelists panelist) {
		return panelistService.addPanelist(panelist);
	}
	@PutMapping("/panelists")
		public Panelists updateOne(@RequestBody Panelists panelist) {
			return panelistService.updatePanelist(panelist);
		}
	@DeleteMapping("/panelists/{email}")
	public void deleteById(@PathVariable String email) {
		panelistService.deletePanelist(email);
	}

		

	}


