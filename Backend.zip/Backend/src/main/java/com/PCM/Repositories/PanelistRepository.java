package com.PCM.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PCM.Model.Panelists;

public interface PanelistRepository extends JpaRepository<Panelists, String> {

}
