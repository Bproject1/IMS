import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Candidate } from '../candidate';
import { CandidateService } from '../candidate.service';

@Component({
  selector: 'app-candidate-list',
  templateUrl: './candidate-list.component.html',
  styleUrls: ['./candidate-list.component.css']
})
export class CandidateListComponent implements OnInit {

  candidates : Candidate[];

  constructor(private candidateService : CandidateService , private router :Router) { }

  ngOnInit(): void {

  this.getCandidates();
  
}

  private getCandidates(){
    this.candidateService.getCandidatesList().subscribe(data => {
        this.candidates = data;
        console.log(this.candidates);
        console.log(data);
 
    });
  }

    gotoCreateCandidate(){
      this.router.navigate(['/create-candidate']);
    }

    gotoUpdateCandidate(id:number){
      console.log(id);
      this.router.navigate(['/update-candidate',id] );
    }

      deleteCandidate(id:number){
      this.candidateService.deleteCandidate(id).subscribe( data => {
        console.log(data);
        this.getCandidates(); 
      });
    }

    gotoAllProjects(){
      this.router.navigate(['/projects']);
    }

  //  this.candidates = [{
  //    "id":1,
  //    "firstname" : "al",
  //    "lastname" :"pha" ,
  //    "panelist" : "p1",
  //    "status" : "pending",
  //    "technology" : "java"
  //  },
  //  {
  //   "id":2 ,
  //   "firstname" : "beta",
  //   "lastname" :"pha" ,
  //   "panelist" : "p2",
  //   "status" : "pending",
  //   "technology" : "hagha"
  // }]


  

}
