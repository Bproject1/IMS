package com.PCM.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PCM.dao.CandidateDao;
import com.PCM.entities.Candidates;
@Service
public class CandidateServiceImpl implements CandidateService {
	
	@Autowired
	private CandidateDao candidateDao;


	@Override
	public List<Candidates> getCandidates() {
		// TODO Auto-generated method stub
		return candidateDao.findAll();
	}

	@Override
	public Optional<Candidates> getCandidate(long id) {
		// TODO Auto-generated method stub
		return candidateDao.findById(id);
		
	}

	@Override
	public Candidates addCandidate(Candidates candidates) {
		// TODO Auto-generated method stub
		return candidateDao.save(candidates);
	}

	@Override
	public Candidates updateCandidate(Candidates candidates) {
		// TODO Auto-generated method stub
		return candidateDao.save(candidates);
		
	}

	@Override
	public void deleteCandidate(long id) {
		// TODO Auto-generated method stub
		candidateDao.deleteById(id);

	}

}
