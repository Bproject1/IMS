package com.PCM.Controller;


import com.PCM.LogicCode.addCandidate.*;
import com.PCM.Model.*;
import com.PCM.LogicCode.getCandidate.*;
import com.PCM.LogicCode.UpdateCandidate.*;
import com.PCM.Services.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/v1/candidates")
@CrossOrigin(origins = "*")
public class CandidateController {

    @Autowired
    private CandidateService candidateService;

    @Autowired
    private UserService userService;

    @GetMapping
    public List<GetCandidate> list() {

        List<Candidates> candidates = candidateService.getAllCandidates();

        List<GetCandidate> getCandidates = new ArrayList<>();

        for (Candidates candidate: candidates) {
            getCandidates.add(userService.getCandidate(candidate.getId()));
        }

        return getCandidates;
    }

    @GetMapping
    @RequestMapping("{id}")
    public GetCandidate get(@PathVariable Long id) {
        return userService.getCandidate(id);
    }

    @PostMapping
    public Candidates create(@RequestBody Candidates candidate) {
        return candidateService.saveCandidate(candidate);

    }

    @RequestMapping(value = "/updatecandidate")
    public Candidates updateCandidate(@RequestBody Candidates candidate) {
        return candidateService.updateCandidate(candidate);
    }

//    @GetMapping(value = "/allocateallpending")
//    public void allocateAllpendingCandidates() {
//        candidateService.allocateAllPending();
//    }

}
