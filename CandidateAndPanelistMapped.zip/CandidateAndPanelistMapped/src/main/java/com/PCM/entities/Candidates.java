package com.PCM.entities;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Candidates")
public class Candidates {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private long id;
		
		@Column(name = "firstname")
		private String firstname;
		
		@Column(name = "lastname")
		private String lastname;
		
		@Column(name = "technology")
		private String technology;
		
		
		@Column(name = "status")
		private String status;
		
		@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	    @JoinColumn(name = "pan_email", referencedColumnName = "email")
		@JsonIgnoreProperties("can")
		private Panelists panelists;
		
		
		
		
		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}
		
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public String getTechnology() {
			return technology;
		}
		public void setTechnology(String technology) {
			this.technology = technology;
		}

		
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}

		public Candidates(long id, String firstname, String lastname, String technology, String status) {
			super();
			this.id = id;
			this.firstname = firstname;
			this.lastname = lastname;
			this.technology = technology;
			this.status = status;
		}

		public Candidates() {
			super();
			// TODO Auto-generated constructor stub
		}
		

		
	}



