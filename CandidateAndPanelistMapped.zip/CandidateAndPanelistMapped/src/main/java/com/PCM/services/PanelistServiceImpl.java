package com.PCM.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.PCM.dao.PanelistsDao;
import com.PCM.entities.Panelists;

@Service
public class PanelistServiceImpl implements PanelistService {
	@Autowired
	private PanelistsDao panelistsDao;

	@Override
	public List<Panelists> getPanelist() {
		// TODO Auto-generated method stub
		return panelistsDao.findAll();
	}

	@Override
	public Optional<Panelists> getPanel(String email) {
		// TODO Auto-generated method stub
		return panelistsDao.findById(email);
	}

	@Override
	public Panelists addPanelist(Panelists panelists) {
		// TODO Auto-generated method stub
		return panelistsDao.save(panelists);
	}

	@Override
	public Panelists updatePanelist(Panelists panelists) {
		// TODO Auto-generated method stub
		return panelistsDao.save(panelists);
	}

	@Override
	public void deletePanelist(String email) {
		// TODO Auto-generated method stub
		panelistsDao.deleteById(email);
		
	}

}
