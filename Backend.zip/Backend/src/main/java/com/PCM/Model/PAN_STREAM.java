package com.PCM.Model;

public class PAN_STREAM {
	
	private Streams stream;
	
	
	private Panelists panelists;

}
