package com.PCM.Model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "candidate_panelist")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})

public class PanCan {
	

	
	

	    @EmbeddedId
	    private CandidatePanelistId id;

	    @ManyToOne
	    @MapsId("candidateId")
	    @JoinColumn(name = "ccandidate_id")
	    @JsonIgnore
	    private Candidates candidatesAssigned;

	    @ManyToOne
	    @MapsId("panUsername")
	    @JoinColumn(name = "cpan_username")
	    @JsonIgnore
	    private Panelists panAssigned;

	    @Column(name = "status")
	    private String status;

	    

	    public CandidatePanelistId getId() {
			return id;
		}



		public void setId(CandidatePanelistId id) {
			this.id = id;
		}



		public Candidates getCandidatesAssigned() {
			return candidatesAssigned;
		}



		public void setCandidatesAssigned(Candidates candidatesAssigned) {
			this.candidatesAssigned = candidatesAssigned;
		}



		public Panelists getpanAssigned() {
			return panAssigned;
		}



		public void setpanAssigned(Panelists panAssigned) {
			this.panAssigned = panAssigned;
		}



		public String getStatus() {
			return status;
		}



		public void setStatus(String status) {
			this.status = status;
		}



		public PanCan() {
	    }



		public PanCan(CandidatePanelistId id, Candidates candidatesAssigned, Panelists panAssigned, String status) {
			super();
			this.id = id;
			this.candidatesAssigned = candidatesAssigned;
			this.panAssigned = panAssigned;
			this.status = status;
		}



		@Override
		public String toString() {
			return "PanCan [id=" + id + ", candidatesAssigned=" + candidatesAssigned + ", usersAssigned="
					+ panAssigned + ", status=" + status + "]";
		}
		
		

	  
	}



