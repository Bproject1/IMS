package com.bridgeproject.interview.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="panelists")
public class Panelist {

	@Id
	private String username;
	
    @Column(name="panelistName")
	private String panelistName;
    
    @Column(name="panelistStream")
   	private String panelistStream;
    
    @Column(name="panelistExperience")
   	private String panelistExperience;
    
    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
    @JsonIgnoreProperties("panelist")
    private List<Candidate> can=new ArrayList<Candidate>();

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPanelistName() {
		return panelistName;
	}

	public void setPanelistName(String panelistName) {
		this.panelistName = panelistName;
	}

	public String getPanelistStream() {
		return panelistStream;
	}

	public void setPanelistStream(String panelistStream) {
		this.panelistStream = panelistStream;
	}

	public String getPanelistExperience() {
		return panelistExperience;
	}

	public void setPanelistExperience(String panelistExperience) {
		this.panelistExperience = panelistExperience;
	}

	public List<Candidate> getCan() {
		return can;
	}

	public void setCan(List<Candidate> can) {
		this.can = can;
	}

	public Panelist(String username, String panelistName, String panelistStream, String panelistExperience,
			List<Candidate> can) {
		super();
		this.username = username;
		this.panelistName = panelistName;
		this.panelistStream = panelistStream;
		this.panelistExperience = panelistExperience;
		this.can = can;
	}

	public Panelist() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Panelist [username=" + username + ", panelistName=" + panelistName + ", panelistStream="
				+ panelistStream + ", panelistExperience=" + panelistExperience + ", can=" + can + "]";
	}
    
}
