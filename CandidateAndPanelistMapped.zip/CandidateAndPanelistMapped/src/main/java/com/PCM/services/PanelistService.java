package com.PCM.services;
import java.util.List;
import java.util.Optional;

import com.PCM.entities.Panelists;
public interface PanelistService {
	public List<Panelists> getPanelist();
	public Optional<Panelists> getPanel(String email);
	public Panelists addPanelist(Panelists panelists);
	public Panelists updatePanelist(Panelists panelists);
	public void deletePanelist(String email);

}




	
		

	


