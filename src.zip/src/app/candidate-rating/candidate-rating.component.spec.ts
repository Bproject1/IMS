import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateRatingComponent } from './candidate-rating.component';

describe('CandidateRatingComponent', () => {
  let component: CandidateRatingComponent;
  let fixture: ComponentFixture<CandidateRatingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CandidateRatingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateRatingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
