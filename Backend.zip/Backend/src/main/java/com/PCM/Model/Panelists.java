package com.PCM.Model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.*;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="panelist")
public class Panelists {
	
	    @Id
	    @Column(name="pan_username")
		private String username;
	    
	    @Column(name="pan_name")
	    private String panName;
	    
	    
	    @ManyToMany
	    @JoinTable(
	            name = "user_stream",
	            joinColumns = @JoinColumn(name = "uuser_id"),
	            inverseJoinColumns = @JoinColumn(name = "ustream_id")
	    )
	    @JsonIgnore
	    private List<Streams> stream;
	    
	    @OneToMany(mappedBy = "panAssigned")
	    @JsonIgnore
	    private List<PanCan> pancan = new ArrayList<>();

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPanName() {
			return panName;
		}

		public void setPanName(String panName) {
			this.panName = panName;
		}

	

		public List<Streams> getStream() {
			return stream;
		}

		public void setStream(List<Streams> stream) {
			this.stream = stream;
		}

		public Panelists() {
			super();
			// TODO Auto-generated constructor stub
		}

		public List<PanCan> getPancan() {
			return pancan;
		}

		public void setPancan(List<PanCan> pancan) {
			this.pancan = pancan;
		}

		public Panelists(String username, String panName, List<Streams> stream, List<PanCan> pancan) {
			super();
			this.username = username;
			this.panName = panName;
			this.stream = stream;
			this.pancan = pancan;
		}
		
		
		
		
	

}
