import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Candidate } from '../candidate';
import { CandidateService } from '../candidate.service';
import { Panelist } from '../panelist';
import { PanelistService } from '../panelist.service';

@Component({
  selector: 'app-create-candidate',
  templateUrl: './create-candidate.component.html',
  styleUrls: ['./create-candidate.component.css']
})
export class CreateCandidateComponent implements OnInit {

  candidate : Candidate = new Candidate();
  panelist:Panelist[];

  constructor(private candidateService : CandidateService , private router:Router , private panelistService: PanelistService) { }

  ngOnInit(): void {
    this.getPanelist();
    console.log(this.panelist);
  }

  saveCandidate(){
     this.candidateService.createCandidate(this.candidate).subscribe(data => {
       console.log(data);
       this.gotoCandidateList();
     },
     error => console.log(error));
  }

  gotoCandidateList(){
     this.router.navigate(['/candidates']);
  }

  onSubmit(){
    console.log(this.candidate);
    this.saveCandidate();  
  }

  private getPanelist(){
    this.panelistService.getPanelistsList().subscribe(data => {
        this.panelist = data;

        console.log(this.panelist);
        console.log(data);
 
    });
  }
  

}
