package com.PCM.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PCM.Model.Candidates;

public interface CandidatesRepository extends JpaRepository<Candidates, Long> {

}
