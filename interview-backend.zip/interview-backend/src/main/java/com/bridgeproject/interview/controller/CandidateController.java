package com.bridgeproject.interview.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bridgeproject.interview.exception.ResourceNotFoundException;
import com.bridgeproject.interview.model.Candidate;
import com.bridgeproject.interview.repository.CandidateRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class CandidateController {

	@Autowired
	private CandidateRepository candidateRepository;
	
	//all candidates
	
	@GetMapping("/candidates")
	public List<Candidate> getAllCandidates(){
		return candidateRepository.findAll();	
	}
	
	//create candidates api
	@PostMapping("/candidates")
	public Candidate createCandidate(@RequestBody Candidate candidate) {
		System.out.print(candidate);
		return candidateRepository.save(candidate);
	}
	
	// get candidate byId 
	@GetMapping("candidates/{id}")
	public ResponseEntity<Candidate> getCandidateById(@PathVariable	Long id) {
		
		Candidate candidate = candidateRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Candidate not Found with id : " + id));
		return ResponseEntity.ok(candidate);
	}
	
	//update candidate rest api
	@PutMapping("/candidates/{id}")
	public ResponseEntity<Candidate> updateCandiate(@PathVariable Long id , @RequestBody Candidate candidateDetails){
		Candidate candidate = candidateRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Candidate not Found with id : " + id));
		candidate.setFullName(candidateDetails.getFullName());
		candidate.setEmailId(candidateDetails.getEmailId());
		candidate.setPanelist_name(candidateDetails.getPanelist_name());
		candidate.setStatus(candidateDetails.getStatus());
		candidate.setStream(candidateDetails.getStream());
		candidate.setProject(candidateDetails.getProject());
		//candidate.setPlId(candidateDetails.getPlId());
		
		Candidate updatedCandidate = candidateRepository.save(candidate);
		return ResponseEntity.ok(updatedCandidate);
		
	}
	
	//delete candidate rest api
	@DeleteMapping("/candidates/{id}")
	public ResponseEntity<Map<String , Boolean>> deleteCandidate(@PathVariable Long id){
		Candidate candidate = candidateRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Candidate not Found with id : " + id));
	    
		candidateRepository.delete(candidate);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	
	
}
 