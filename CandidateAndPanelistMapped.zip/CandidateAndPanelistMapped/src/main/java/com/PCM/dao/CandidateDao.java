package com.PCM.dao;
import java.awt.print.Pageable;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PCM.entities.Candidates;
import com.PCM.entities.Panelists;
@Repository
public interface CandidateDao extends JpaRepository<Candidates,Long> {
//List<Candidates> findCandidatesbypanelist(String email);
//Optional<Candidates> findbyidandEamil(long id,String email);

}

