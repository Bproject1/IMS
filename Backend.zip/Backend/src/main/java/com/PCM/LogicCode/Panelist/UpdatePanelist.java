package com.PCM.LogicCode.Panelist;

import java.util.List;

public class UpdatePanelist {
    private String pan_username;
   
    private List<Long> streamIds;

	public String getPan_username() {
		return pan_username;
	}

	public void setPan_username(String pan_username) {
		this.pan_username = pan_username;
	}

	public List<Long> getStreamIds() {
		return streamIds;
	}

	public void setStreamIds(List<Long> streamIds) {
		this.streamIds = streamIds;
	}

	public UpdatePanelist(String pan_username, List<Long> streamIds) {
		super();
		this.pan_username = pan_username;
		this.streamIds = streamIds;
	}

	public UpdatePanelist() {
		super();
		// TODO Auto-generated constructor stub
	}

   
}
