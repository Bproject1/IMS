package com.example.SpringApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginSpringBootApplication.class, args);
	}

}
