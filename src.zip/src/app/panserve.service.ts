import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { Candidate } from './candidate';
import { Panel } from './panel';

@Injectable({
  providedIn: 'root'
})
export class PanserveService {
private baseURL='http://localhost:8080/candidates';
private panURL='http://localhost:8080/panelists';

  constructor(private httpClient:HttpClient) { }

  getCandidatesList(): Observable<Candidate[]>{
    return this.httpClient.get<Candidate[]>(this.baseURL);
  }
  getCandidateId(id: number): Observable<Candidate>{
    return this.httpClient.get<Candidate>(`${this.baseURL}/${id}`);
  }
  getCPanelistsList(): Observable<Panel[]>{
    return this.httpClient.get<Panel[]>(this.panURL);
  }
  getPanelistId(email: String): Observable<Panel>{
    return this.httpClient.get<Panel>(`${this.panURL}/${email}`);
  }

}
