package com.PCM.Services;

import com.PCM.Model.*;
import com.PCM.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class StreamService {

    @Autowired
    private StreamRepository streamRepository;

    public Streams findStreamById(Long streamId) {
        if(streamRepository.existsById(streamId)) {
            return streamRepository.getById(streamId);
        }
        return null;
    }
    public List<Streams> findStreams() {
        List<Streams> streams =  streamRepository.findAll();
       

        return streams;
    }
}
