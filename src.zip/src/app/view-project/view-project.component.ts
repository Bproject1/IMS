import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Candidate } from '../candidate';
import { CandidateService } from '../candidate.service';
import { Project } from '../project';
import { ProjectService } from '../project.service';

@Component({
  selector: 'app-view-project',
  templateUrl: './view-project.component.html',
  styleUrls: ['./view-project.component.css']
})
export class ViewProjectComponent implements OnInit {
 
  id:number;
  project:Project = new Project;
  candidates : Candidate[];
  constructor(private route:ActivatedRoute , private projectService : ProjectService , private candidateService : CandidateService ,  private router : Router) { }

  ngOnInit(): void {
    this.id=this.route.snapshot.params['id'];

    this.projectService.getProjectById(this.id).subscribe(data => {
       this.project = data;
    });

    //
    this.getCandidates();

  }

  getProgress(a:number,b:number){
    console.log("callingggggggg");
     return (b/a)*100;
  }

  private getCandidates(){
    this.candidateService.getCandidatesList().subscribe(data => {
        this.candidates = data;
        console.log(this.candidates);
        console.log(data);
 
    });
  }

  onSubmit(){
    console.log("in onSubmit");
    this.projectService.updateProject(this.id , this.project).subscribe(data => {
      this.gotoProjectList();
      console.log("done");
    }, error => console.log(error));
  }

  gotoProjectList(){
    this.router.navigate(['/projects']);
  }

  gotoSelectCandidate(id:number){
    console.log(id);
    this.router.navigate(['/select-project-candidate',id] );
  }

}
