import { Component } from '@angular/core';
import { Panel } from './panel';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Panelists';
  pan!:Panel[];
}
