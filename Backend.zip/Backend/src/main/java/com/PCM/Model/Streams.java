package com.PCM.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@Entity
@Table(name = "streams")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Streams {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "stream_id")
	    private Long id;

	    @Column(name = "stream_name")
	    private String streamName;

	    @OneToMany(mappedBy = "stream", cascade = CascadeType.ALL)
	    @JsonIgnore
	    private List<Candidates> candidates;


//	    @OneToMany(mappedBy = "stream")
//	    @JsonIgnore
//	    private List<ProjectStream> projectStreams = new ArrayList<>();

	    @ManyToMany
	    @JoinTable(
	            name = "user_stream",
	            joinColumns = @JoinColumn(name = "ustream_id"),
	            inverseJoinColumns = @JoinColumn(name = "uuser_id")
	    )
	    @JsonIgnore
	    private List<Panelists> streamPanelists;

	    public Streams() {

	    }

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getStreamName() {
			return streamName;
		}

		public void setStreamName(String streamName) {
			this.streamName = streamName;
		}

		public List<Candidates> getCandidates() {
			return candidates;
		}

		public void setCandidates(List<Candidates> candidates) {
			this.candidates = candidates;
		}

		public List<Panelists> getStreamPanelists() {
			return streamPanelists;
		}

		public void setStreamPanelists(List<Panelists> streamPanelists) {
			this.streamPanelists = streamPanelists;
		}

		public Streams(Long id, String streamName, List<Candidates> candidates, List<Panelists> streamPanelists) {
			super();
			this.id = id;
			this.streamName = streamName;
			this.candidates = candidates;
			this.streamPanelists = streamPanelists;
		}

		@Override
		public String toString() {
			return "Streams [id=" + id + ", streamName=" + streamName + ", candidates=" + candidates
					+ ", streamPanelists=" + streamPanelists + "]";
		}

	   
	    }
	

