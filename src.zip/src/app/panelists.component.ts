import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Panel } from './panel';
import { ActivatedRoute } from '@angular/router';
import { PanserveService } from './panserve.service';
import { Candidate } from './candidate';
import { CandidateListComponent } from './candidate-list.component';


@Component({
  selector: 'app-panelists',
  templateUrl: './panelists.component.html',
  styleUrls: ['./panelists.component.css']
})
export class PanelistsComponent implements OnInit {
  
  id!: number;
  cand!: Candidate;
  constructor(private route: ActivatedRoute, private panSer:PanserveService ) { }


  myreactiveForm!:FormGroup;
  

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];

    // this.cand=new Candidate();
    this.panSer.getCandidateId(this.id).subscribe( data => {
      this.cand = data;
    });
  
    this.myreactiveForm=new FormGroup({
      'Rating':new FormControl(null),
      'Status':new FormControl(null)
    });
  }

}
