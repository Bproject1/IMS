

export class Candidate {

    id: number ;
    fullName: string;
    emailId: string;
    panelist_name: string;
    status: string;
    stream:string;
    pan_username : string;
    project:string;
   
}
