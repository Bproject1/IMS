package com.PCM.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.PCM.entities.Panelists;
@Repository
public interface PanelistsDao extends JpaRepository<Panelists,String> {
	

}
