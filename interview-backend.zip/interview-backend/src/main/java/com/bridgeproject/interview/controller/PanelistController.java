package com.bridgeproject.interview.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bridgeproject.interview.exception.ResourceNotFoundException;
import com.bridgeproject.interview.model.Panelist;

import com.bridgeproject.interview.repository.PanelistRepository;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/v1/")
public class PanelistController {

	@Autowired
	private PanelistRepository panelistRepository ;
	
	// all panelist
	@GetMapping("/panelists")	
	public List<Panelist> getAllPanelists(){
		return panelistRepository.findAll();	
	}
	
	// get panelist by Id 
	@GetMapping("panelists/{username}")
	public ResponseEntity<Panelist> getPanelistById(@PathVariable String username) {
			
		Panelist panelist = panelistRepository.findById(username)
				.orElseThrow(() -> new ResourceNotFoundException("Panelist not Found with username : " +username));
		return ResponseEntity.ok(panelist);
	}
	
	//create panelist api
	@PostMapping("/panelists")
	public Panelist createPanelist(@RequestBody Panelist panelist) {
		return panelistRepository.save(panelist);
	}
	
	//delete panelist rest api
	@DeleteMapping("/panelists/{id}")
	public ResponseEntity<Map<String , Boolean>> deletePanelist(@PathVariable String username){
		Panelist panelist = panelistRepository.findById(username)
				.orElseThrow(() -> new ResourceNotFoundException("Panelist not Found with username : " + username));
	    
		panelistRepository.delete(panelist);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}




																		
		
}
