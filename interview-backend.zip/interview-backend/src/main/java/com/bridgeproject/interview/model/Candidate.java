package com.bridgeproject.interview.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "Candidates")
public class Candidate {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "fullName")
	private String fullName;
	
	@Column(name = "emailId")
	private String emailId;
	
	@Column(name = "stream")
	private String stream;
	
	@Column(name = "project")
	private String project;
	
	@Column(name = "panelist_name")
	private String panelist_name;
	
	@Column(name = "status")
	private String status;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "pan_username", referencedColumnName = "username")
	@JsonIgnoreProperties("can")
	private Panelist panelists;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getStream() {
		return stream;
	}

	public void setStream(String stream) {
		this.stream = stream;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	

	public Panelist getPanelists() {
		return panelists;
	}

	public void setPanelists(Panelist panelists) {
		this.panelists = panelists;
	}

	public String getPanelist_name() {
		return panelist_name;
	}

	public void setPanelist_name(String panelist_name) {
		this.panelist_name = panelist_name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	@Override
	public String toString() {
		return "Candidate [id=" + id + ", fullName=" + fullName + ", emailId=" + emailId + ", stream=" + stream
				+ ", project=" + project + ", panelist_name=" + panelist_name + ", status=" + status + ", panelists="
				+ panelists + "]";
	}

	public Candidate() {
		super();
		
	}

	public Candidate(long id, String fullName, String emailId, String stream, String project, String panelist_name,
			String status) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.emailId = emailId;
		this.stream = stream;
		this.project = project;
		this.panelist_name = panelist_name;
		this.status = status;
		
	}

	
	

	
	
	


	


	
	
	

	
}
