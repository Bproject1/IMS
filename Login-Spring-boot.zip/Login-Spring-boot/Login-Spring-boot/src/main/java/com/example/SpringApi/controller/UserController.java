package com.example.SpringApi.controller;


import com.example.SpringApi.entity.User;
import com.example.SpringApi.model.UserRequestModel;
import com.example.SpringApi.model.UserResponseModel;
import com.example.SpringApi.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")    //   By default allows access to request from all origin . To restrict set: @CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;


        /*
         Register User with Request Body Ex:
           {
             "username": "xxxx@yyyy.com",
             "password": "123"
           }
        */

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@Valid @RequestBody UserRequestModel newUser) {
        if(!userService.findExistingUser(newUser)){
            userService.save(newUser);
            return new ResponseEntity<>("Registered", HttpStatus.OK);
        }
        else return new ResponseEntity<>("Already Exist",HttpStatus.CONFLICT);
    }

    @PostMapping("/login")    // login with 'id' as path variable 'http://localhost:8080/users/login/5'
    public String loginUser(  @RequestBody User user) {
        return "success";

//        System.out.println("login");
//        if(id == null){
//            return new ResponseEntity<>("Invalid Id",HttpStatus.BAD_REQUEST);
//        }else{
//            if(userService.updateUserLoginStatus(id, true))return new ResponseEntity<>("Logged in",HttpStatus.OK);
//            else return new ResponseEntity<>("User Not Found",HttpStatus.NOT_FOUND);
//        }
    }



    @GetMapping("/all")
    public List<UserResponseModel> getAllUsers(){
        return userService.allUsers();
    }

    @PostMapping("/logout/{id}")   // logout with 'id' as path variable 'http://localhost:8080/users/logout/5'
    public ResponseEntity<String> logUserOut(@PathVariable("id") Long id) {
        if (userService.updateUserLoginStatus(id, false)) {
            return new ResponseEntity<>("Logged Out", HttpStatus.OK);
        } else
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
    }


}
