package com.example.SpringApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
