export class Project {
    id:number;
    projectName:string;
    stream:string;
    requirement:number;
    selected:number
}
