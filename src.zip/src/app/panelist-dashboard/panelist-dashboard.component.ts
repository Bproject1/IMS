import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Panelist } from '../panelist';
import { PanelistService } from '../panelist.service';

@Component({
  selector: 'app-panelist-dashboard',
  templateUrl: './panelist-dashboard.component.html',
  styleUrls: ['./panelist-dashboard.component.css']
})
export class PanelistDashboardComponent implements OnInit {

  username:String;
  panelist:Panelist;

  constructor(private panelistService :PanelistService,private router: Router,private route:ActivatedRoute) { }

  ngOnInit(): void {
    this.username=this.route.snapshot.params['username'];
    this.panelistService.getPanelistById(this.username).subscribe(data => {
      console.log(data);
      this.panelist = data;
    });
  }

  gotoCandidateRating(id:number){
    this.router.navigate(['panelists',this.username,id]);
  }

}
