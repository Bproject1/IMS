package com.PCM.entities;
import java.io.Serializable;
import java.util.*;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="panelist")
public class Panelists {
	    @Id
		private String email;
	    @Column(name="name_pan")
		private String name;
	    
	    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	    @JsonIgnoreProperties("panelists")
	   
	    private List<Candidates> can=new ArrayList<Candidates>();
		
		
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public List<Candidates> getCan() {
			return can;
		}
		public void setCan(List<Candidates> can) {
			this.can = can;
		}
		
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		@Override
		public String toString() {
			return "Panelists [email=" + email + ", name=" + name + ", can=" + can + "]";
		}
		public Panelists() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Panelists(String email, String name, List<Candidates> can) {
			super();
			this.email = email;
			this.name = name;
			this.can = can;
		}
		
		

	}



