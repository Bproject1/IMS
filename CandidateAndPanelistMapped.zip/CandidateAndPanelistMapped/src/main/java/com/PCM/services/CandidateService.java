package com.PCM.services;

import java.util.List;
import java.util.Optional;

import com.PCM.entities.Candidates;


public interface CandidateService  {
	public List<Candidates> getCandidates();
	public Optional<Candidates> getCandidate(long id);
	public Candidates addCandidate(Candidates candidates);
	public Candidates updateCandidate(Candidates candidates);
	public void deleteCandidate(long id);


}
