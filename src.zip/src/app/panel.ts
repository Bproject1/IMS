import { Candidate } from "./candidate";

export class Panel {
    email!:String;
    name!:String;
    can!:Candidate[];
}
