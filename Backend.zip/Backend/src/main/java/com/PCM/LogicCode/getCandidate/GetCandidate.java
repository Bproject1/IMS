package com.PCM.LogicCode.getCandidate;

import java.util.ArrayList;
import java.util.List;


public class GetCandidate {

    private Long candidateId;
    private String candidateName;
//    private Long candidateExperience;
//    private GetProject project = new GetProject();
    private GetStream stream = new GetStream();
    
    private String candidateStatus;

    private List<GetUser> getUsers = new ArrayList<>();

    public GetCandidate() {
    }

	public Long getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(Long candidateId) {
		this.candidateId = candidateId;
	}

	public String getCandidateName() {
		return candidateName;
	}

	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}

	public GetStream getStream() {
		return stream;
	}

	public void setStream(GetStream stream) {
		this.stream = stream;
	}

	public String getCandidateStatus() {
		return candidateStatus;
	}

	public void setCandidateStatus(String candidateStatus) {
		this.candidateStatus = candidateStatus;
	}

	public List<GetUser> getGetUsers() {
		return getUsers;
	}

	public void setGetUsers(List<GetUser> getUsers) {
		this.getUsers = getUsers;
	}

	public GetCandidate(Long candidateId, String candidateName, GetStream stream, String candidateStatus,
			List<GetUser> getUsers) {
		super();
		this.candidateId = candidateId;
		this.candidateName = candidateName;
		this.stream = stream;
		this.candidateStatus = candidateStatus;
		this.getUsers = getUsers;
	}

	@Override
	public String toString() {
		return "GetCandidate [candidateId=" + candidateId + ", candidateName=" + candidateName + ", stream=" + stream
				+ ", candidateStatus=" + candidateStatus + ", getUsers=" + getUsers + "]";
	}

   
}
