export interface Candidate {
    id:number;
    firstname:String;
    lastname:String;
    technology:String;
    status:String;
}
