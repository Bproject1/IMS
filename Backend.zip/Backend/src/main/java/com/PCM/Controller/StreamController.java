package com.PCM.Controller;

import com.PCM.Model.*;
import com.PCM.Services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/streams")
@CrossOrigin(origins = "*")
public class StreamController {
    @Autowired
    private StreamService streamService;

    @GetMapping
    public List<Streams> getStreams() {
        return streamService.findStreams();
    }

}
