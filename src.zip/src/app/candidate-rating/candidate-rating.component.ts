import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Candidate } from '../candidate';
import { CandidateService } from '../candidate.service';

@Component({
  selector: 'app-candidate-rating',
  templateUrl: './candidate-rating.component.html',
  styleUrls: ['./candidate-rating.component.css']
})
export class CandidateRatingComponent implements OnInit {

  id: number;
  username:string;
  candi: Candidate;

  constructor(private candidateService : CandidateService,private route: ActivatedRoute) { }

 

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.username = this.route.snapshot.params['username'];
    console.log(this.id);
    console.log(this.username);

    this.candidateService.getCandidateById(this.id).subscribe(data => {
      this.candi=data;
   },error => console.log(error));
  }

}
