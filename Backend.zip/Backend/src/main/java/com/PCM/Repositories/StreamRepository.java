package com.PCM.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PCM.Model.Streams;

public interface StreamRepository extends JpaRepository<Streams, Long> {

}
