import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectCandidateProjectComponent } from './select-candidate-project.component';

describe('SelectCandidateProjectComponent', () => {
  let component: SelectCandidateProjectComponent;
  let fixture: ComponentFixture<SelectCandidateProjectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelectCandidateProjectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectCandidateProjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
