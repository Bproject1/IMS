import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PanelistDashboardComponent } from './panelist-dashboard.component';

describe('PanelistDashboardComponent', () => {
  let component: PanelistDashboardComponent;
  let fixture: ComponentFixture<PanelistDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PanelistDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PanelistDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
