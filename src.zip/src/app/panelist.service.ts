import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Panelist } from './panelist';

@Injectable({
  providedIn: 'root'
})
export class PanelistService {

  private panURL='http://localhost:8080/api/v1/panelists';
 
  constructor(private httpClient:HttpClient) { }

  getPanelistsList(): Observable<Panelist[]>{
    return this.httpClient.get<Panelist[]>(this.panURL);
  }

  getPanelistById(username: String): Observable<Panelist>{
    return this.httpClient.get<Panelist>(`${this.panURL}/${username}`);
  }
}
