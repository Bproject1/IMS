package com.PCM.Model;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
//import com.PCM.entities.Panelists;

@Entity
@Table(name = "Candidates")
public class Candidates {
	
	

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name="CAND_ID")
		private Long id;
		
		@Column(name = "name")
		private String name;
		
		@ManyToOne
	    @JoinColumn(name = "cstream_id")
		
		private Streams stream;
		
		
		@Column(name = "status")
		private String status;
		
		@OneToMany(mappedBy = "candidatesAssigned")
	    @JsonIgnore
	    private List<PanCan> pancan = new ArrayList<>();
		
		

		
		
		
		

		public long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}
		
		
		
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

	

		
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}

	
		
		public List<PanCan> getPancan() {
			return pancan;
		}

		public void setPancan(List<PanCan> pancan) {
			this.pancan = pancan;
		}

		public Streams getStream() {
			return stream;
		}

		public void setStream(Streams stream) {
			this.stream = stream;
		}

		public Candidates() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Candidates(Long id, String name, Streams stream, String status, List<PanCan> pancan) {
			super();
			this.id = id;
			this.name = name;
			this.stream = stream;
			this.status = status;
			this.pancan = pancan;
		}
		

//		public Panelists getPanelists() {
//			return panelists;
//		}
//
//		public void setPanelists(Panelists panelists) {
//			this.panelists = panelists;
//		}
//		

		
	}




