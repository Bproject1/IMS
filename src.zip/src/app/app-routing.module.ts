import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CandidateListComponent } from './candidate-list.component';
import { PanelistsComponent } from './panelists.component';

const routes: Routes = [
  {path: 'panelist/:email', component: CandidateListComponent},
  
  {path: '', redirectTo: 'panelist/:email', pathMatch: 'full'},
  
  {path: 'candidate-details/:id', component: PanelistsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
