package com.PCM.LogicCode.UpdateCandidate;

public class GetUpdateCandidate {
    private Long candidateId;
    private String pan_username;
    
    private String status;

    public GetUpdateCandidate() {
    }

    public GetUpdateCandidate(Long candidateId, String pan_username, String status) {
        this.candidateId = candidateId;
        this.pan_username = pan_username;
      
        this.status = status;
    }

    public String getPan_Username() {
        return pan_username;
    }

    public void setUserId(String pan_username) {
        this.pan_username = pan_username;
    }

    public Long getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(Long candidateId) {
        this.candidateId = candidateId;
    }

   

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
