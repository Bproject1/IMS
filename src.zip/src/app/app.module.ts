import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { HttpClientModule } from '@angular/common/http'
import { FormsModule } from '@angular/forms';
import { MatProgressBarModule } from "@angular/material/progress-bar"

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CandidateListComponent } from './candidate-list/candidate-list.component';
import { CreateCandidateComponent } from './create-candidate/create-candidate.component';
import { UpdateCandidateComponent } from './update-candidate/update-candidate.component';
import { ProjectListComponent } from './project-list/project-list.component';
import { CreateProjectComponent } from './create-project/create-project.component';
import { ViewProjectComponent } from './view-project/view-project.component';
import { SelectCandidateProjectComponent } from './select-candidate-project/select-candidate-project.component';
import { PanelistDashboardComponent } from './panelist-dashboard/panelist-dashboard.component';
import { CandidateRatingComponent } from './candidate-rating/candidate-rating.component';


@NgModule({
  declarations: [
    AppComponent,
    CandidateListComponent,
    CreateCandidateComponent,
    UpdateCandidateComponent,
    ProjectListComponent,
    CreateProjectComponent,
    ViewProjectComponent,
    SelectCandidateProjectComponent,
    PanelistDashboardComponent,
    CandidateRatingComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    MatProgressBarModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
