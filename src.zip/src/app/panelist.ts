import { Candidate } from "./candidate";

export class Panelist {
    username:string;
    panelistName:string;
    panelistStream:string;
    panelistExperience:number;
    can:Candidate[];
}





