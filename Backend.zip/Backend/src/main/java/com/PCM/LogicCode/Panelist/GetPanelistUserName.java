package com.PCM.LogicCode.Panelist;

public class GetPanelistUserName {
    private String pan_username;

    public String getPan_Username() {
        return pan_username;
    }

    public void setPan_Username(String pan_username) {
        this.pan_username = pan_username;
    }
}
