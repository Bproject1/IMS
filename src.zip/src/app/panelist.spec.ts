import { Panelist } from './panelist';

describe('Panelist', () => {
  it('should create an instance', () => {
    expect(new Panelist()).toBeTruthy();
  });
});
