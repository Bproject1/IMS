package com.PCM.Services;

import com.PCM.Model.*;
import com.PCM.LogicCode.getCandidate.*;
import com.PCM.LogicCode.Panelist.*;
import com.PCM.Repositories.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    @Autowired
    private PanelistRepository panelistRepository;

    @Autowired
    private StreamService streamService;

    @Autowired
    private CandidateService candidateService;

    public Panelists saveUser(Panelists panelist) {
//        User user = new User();
//        user.setUserName(userpass.getUsername());
//        user.setPassword(userpass.getPassword());

        return panelistRepository.saveAndFlush(panelist);
    }

    public Panelists updateUser(UpdatePanelist updatePanelist) {
        Panelists panelist = panelistRepository.getById(updatePanelist.getPan_username());


//        user.setUserLevel(updateUser.getLevel());

//        List<Streams> streams = new ArrayList<>();
//
//        for (Long streamId: updatePanelist.getStreamIds()) {
//            Streams stream = streamService.findStreamById(streamId);
//            streams.add(stream);
//        }
//
//        user.setUserStreams(streams);

        return panelistRepository.saveAndFlush(panelist);
    }

//    public List<UserReturn> getUsers() {
//        List<User> users = userRepository.findAll();
//        List<UserReturn> userReturns = new ArrayList<>();
//        for (User user: users) {
//            userReturns.add(new UserReturn(user.getId(), user.getUserName(), user.getPassword(), user.getUserLevel()));
//        }
//        return userReturns;
//    }
//
//    public UserReturn getUser(Userpass userpass) {
//
//
//        List<UserReturn> userReturns = getUsers();
//        for (UserReturn userReturn: userReturns) {
//            if(userReturn.getUserName().equals(userpass.getUsername()) && userReturn.getPassWord().equals(userpass.getPassword())) {
//                return userReturn;
//            }
//        }
//        return null;
//    }
    public Panelists getUser(String pan_username) {
        return panelistRepository.getById(pan_username);
    }

    public List<GetCandidate> getCandidates(GetPanelistUserName username) {

        Panelists panelist = panelistRepository.getById(username.getPan_Username());
//        System.out.println(user);

        List<PanCan> candidateUsers =  panelist.getPancan();
        List<GetCandidate> candidates = new ArrayList<>();



        for (PanCan candidateUser : candidateUsers) {

            Candidates candidate =  candidateUser.getCandidatesAssigned();
//            System.out.println(candidate.getProject1().getProjectName());
//            GetProject getProject = new GetProject(candidate.getProject1().getId(), candidate.getProject1().getProjectName());
            GetStream getStream =  new GetStream(candidate.getStream().getId(), candidate.getStream().getStreamName());

//            System.out.println(getProject);
//            System.out.println(getStream);
            List<GetUser> getUsers = new ArrayList<>();
            List<PanCan> candidateUsers1 = candidate.getPancan();
            for (PanCan candidateUser1: candidateUsers1) {
                List<Streams> streams = candidateUser1.getpanAssigned().getStream();
                GetUser getUser = new GetUser(candidateUser1.getpanAssigned().getUsername(), candidateUser1.getpanAssigned().getPanName(),
                         candidateUser1.getStatus(), streams);
                getUsers.add(getUser);

            }
            GetCandidate getCandidate = new GetCandidate(candidate.getId(),candidate.getName(),getStream,
                    candidate.getStatus(),getUsers);
            candidates.add(getCandidate);
        }

        return candidates;

    }

    public GetCandidate getCandidate(Long id) {
        Candidates candidate = candidateService.getCandidate(id);

//        GetProject getProject = new GetProject(candidate.getProject1().getId(), candidate.getProject1().getProjectName());
        GetStream getStream =  new GetStream(candidate.getStream().getId(), candidate.getStream().getStreamName());

//            System.out.println(getProject);
//            System.out.println(getStream);
        List<GetUser> getUsers = new ArrayList<>();
        List<PanCan> candidateUsers1 = candidate.getPancan();
        for (PanCan candidateUser1: candidateUsers1) {
            List<Streams> streams = candidateUser1.getpanAssigned().getStream();
            GetUser getUser = new GetUser(candidateUser1.getpanAssigned().getUsername(), candidateUser1.getpanAssigned().getPanName(), candidateUser1.getStatus(), streams);
            getUsers.add(getUser);

        }
        GetCandidate getCandidate = new GetCandidate(candidate.getId(), candidate.getName(), getStream
               ,candidate.getStatus(),getUsers);
        return getCandidate;
    }

    public List<Streams> getStreams(String username) {
        return panelistRepository.getById(username).getStream();
    }


//    public List<GetPanelUser> getPanelUsers() {
//        return panelistRepository.findAll();

//        List<GetPanelUser> panelUsers = new ArrayList<>();
//
//        for (User user: users) {
//            if(user.getUserLevel()!=null && user.getUserLevel().equals("panel")) {
//                Long pending = 0L;
//                for (CandidateUser candidateUser: user.getCandidateUsers()) {
////                    Candidate candidate = candidateUser.getCandidatesAssigned();
//                    if(candidateUser.getStatus().equals("pending")){
//                        pending++;
//                    }
//                }
//                Long total = Long.valueOf(user.getCandidateUsers().size());
//                Long interviewed = total - pending;
//                panelUsers.add(new GetPanelUser(user.getId(), user.getUserName(), interviewed, pending, total));
//            }
//        }
//        return users;
    

    public Panelists getUserByName(String username) {

        List<Panelists> users = panelistRepository.findAll();

        Panelists foundUser;

        for (Panelists user: users) {
            if(user.getPanName().equals(username)) {
                return user;
            }
        }

        return null;
    }
}
