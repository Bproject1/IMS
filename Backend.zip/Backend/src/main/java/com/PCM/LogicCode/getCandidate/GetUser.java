package com.PCM.LogicCode.getCandidate;

import com.PCM.Model.Streams;

import java.util.List;

public class GetUser {
    private String pan_username;
    private String pan_Name;
    
    private String userStatus;
    private List<Streams> userStreams;

    public List<Streams> getUserStreams() {
        return userStreams;
    }

    public void setUserStreams(List<Streams> userStreams) {
        this.userStreams = userStreams;
    }

    public GetUser(String pan_username, String pan_Name, String userStatus, List<Streams> userStreams) {
        this.pan_username = pan_username;
        this.pan_Name = pan_Name;
     
        this.userStatus = userStatus;
        this.userStreams = userStreams;
    }

	public String getPan_username() {
		return pan_username;
	}

	public void setPan_username(String pan_username) {
		this.pan_username = pan_username;
	}

	public String getPan_Name() {
		return pan_Name;
	}

	public void setPan_Name(String pan_Name) {
		this.pan_Name = pan_Name;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	@Override
	public String toString() {
		return "GetUser [pan_username=" + pan_username + ", pan_Name=" + pan_Name + ", userStatus=" + userStatus
				+ ", userStreams=" + userStreams + "]";
	}

   
}
