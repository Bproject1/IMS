package com.PCM.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PCM.Model.CandidatePanelistId;
import com.PCM.Model.PanCan;

public interface PanCanRepository extends JpaRepository<PanCan, CandidatePanelistId> {

}
