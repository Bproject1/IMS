import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { CandidateListComponent } from './candidate-list/candidate-list.component';
import { CandidateRatingComponent } from './candidate-rating/candidate-rating.component';
import { CreateCandidateComponent } from './create-candidate/create-candidate.component';
import { CreateProjectComponent } from './create-project/create-project.component';
import { PanelistDashboardComponent } from './panelist-dashboard/panelist-dashboard.component';
import { ProjectListComponent } from './project-list/project-list.component';
import { SelectCandidateProjectComponent } from './select-candidate-project/select-candidate-project.component';

import { UpdateCandidateComponent } from './update-candidate/update-candidate.component';
import { ViewProjectComponent } from './view-project/view-project.component';

const routes: Routes = [
  {path : 'home' , component : AppComponent},
  {path : '' , redirectTo : 'candidates' , pathMatch : 'full'},
  {path : 'candidates' , component : CandidateListComponent },
  {path : 'create-candidate' , component: CreateCandidateComponent},
  {path : 'update-candidate/:id' , component: UpdateCandidateComponent},
  {path : 'projects' , component:ProjectListComponent },
  {path : 'create-project' , component:CreateProjectComponent},
  {path : 'view-project/:id' , component : ViewProjectComponent},
  {path : 'select-project-candidate/:id' ,component: SelectCandidateProjectComponent},
  {path : 'panelists/:username' , component : PanelistDashboardComponent},
  {path : 'panelists/:username/:id' , component : CandidateRatingComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
