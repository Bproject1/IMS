package com.PCM.Controller;

import com.PCM.Model.*;
import com.PCM.LogicCode.getCandidate.*;
import com.PCM.LogicCode.Panelist.*;
import com.PCM.Services.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/api/v1")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserService userService;

//    @PostMapping(value = "/getuser")
//    public PanReturnNew getUser(@RequestBody Userpass userpass) {
//
//        UserReturn user =  userService.getUser(userpass);
//
//        return new UserReturnNew(user.getUserId(), user.getUserName(), user.getLevel());
//    }

    @GetMapping(value = "/getpanelist/{pan_username}")
    public PanReturnNew getUser(@PathVariable String pan_username) {
        Panelists user = userService.getUser(pan_username);
        return  new PanReturnNew(user.getUsername(), user.getPanName());
    }

//    @GetMapping(value = "/getpanelists")
//    public List<PanReturnNew> getUsers() {
//        List<PanReturnNew> users = new ArrayList<>();
//
//        for (UserReturn user: userService.getUsers()) {
//            users.add(new UserReturnNew(user.getUserId(), user.getUserName(), user.getLevel()));
//        }
//        return users;
//    }

    @PostMapping(value = "/getcandidates")
    public List<GetCandidate> getCandidates(@RequestBody GetPanelistUserName userId) {
        return userService.getCandidates(userId);
    }
    @GetMapping(value = "/panelist/candidate/{id}")
    public GetCandidate getCandidate(@PathVariable("id") Long id) {
        return userService.getCandidate(id);
    }

    @PostMapping(value = "/addpanelist")
    public Panelists addUser(@RequestBody Panelists panelist) {
        return userService.saveUser(panelist);
    }

    @RequestMapping(value = "/updateuser", method = RequestMethod.PUT)
    public Panelists updateUser(@RequestBody UpdatePanelist updateUser) {

        return userService.updateUser(updateUser);
    }

    @GetMapping(value = "/getstreams/{username}")
    public List<Streams> getStreams(@PathVariable String username) {
        return userService.getStreams(username);
    }

//    @GetMapping(value = "/getpaneldetails")
//    public List<GetPanelUser> getPanelUsers() {
//        return userService.g;
//    }
}
