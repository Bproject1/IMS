import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class LoginService {
  url="http://localhost:8080"

  constructor(private http: HttpClient) { 

  }
  doLogin(credentials:any):Observable<any>{
    return this.http.post<any>("/users/login",credentials, {responseType: 'text' as 'json'});
    

 }

//for login
login(username: string){
 localStorage.setItem("user",username)
 return true;
}

//to check login
isLoggedIn(){
 let user=localStorage.getItem("user");
 if(user==undefined || user==='' || user==null)
 return false;
 else return true;
}

//to logout
logout(){
 localStorage.removeItem("user");
 return true;
}

}
