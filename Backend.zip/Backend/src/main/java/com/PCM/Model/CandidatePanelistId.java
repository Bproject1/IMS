package com.PCM.Model;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CandidatePanelistId implements Serializable{
	

	    @Column(name = "candidate_id")
	    private Long candidateId;

	    @Column(name = "pan_Username")
	    private String panUsername;

		public Long getCandidateId() {
			return candidateId;
		}

		public void setCandidateId(Long candidateId) {
			this.candidateId = candidateId;
		}

		public String getPanUsername() {
			return panUsername;
		}

		public void setPanUsername(String panUsername) {
			this.panUsername = panUsername;
		}

		public CandidatePanelistId(Long candidateId, String panUsername) {
			super();
			this.candidateId = candidateId;
			this.panUsername = panUsername;
		}

		public CandidatePanelistId() {
			super();
			// TODO Auto-generated constructor stub
		}

	   

	  

	}



