import { TestBed } from '@angular/core/testing';

import { PanserveService } from './panserve.service';

describe('PanserveService', () => {
  let service: PanserveService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PanserveService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
