import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login1',
  templateUrl: './login1.component.html',
  styleUrls: ['./login1.component.css']
})
export class Login1Component implements OnInit {
  credentials={
    "username":"",
    "password":"",
  }


  constructor(private loginService: LoginService) { }

  ngOnInit(): void {
  }
  onSubmit(){
    this.loginService.doLogin(this.credentials).subscribe(
      response=>{
     console.log(response);
     this.loginService.login(response)
     window.location.href="/dashboard"
    },
    error=>{
      console.log(error);
    })
    console.log("submit");
  }

}
