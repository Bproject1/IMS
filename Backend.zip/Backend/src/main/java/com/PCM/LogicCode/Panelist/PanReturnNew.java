package com.PCM.LogicCode.Panelist;

public class PanReturnNew {

    private String pan_username;
    private String panName;
	public String getPan_username() {
		return pan_username;
	}
	public void setPan_username(String pan_username) {
		this.pan_username = pan_username;
	}
	public String getPanName() {
		return panName;
	}
	public void setPanName(String panName) {
		this.panName = panName;
	}
	public PanReturnNew() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PanReturnNew(String pan_username, String panName) {
		super();
		this.pan_username = pan_username;
		this.panName = panName;
	}
    

   
}
